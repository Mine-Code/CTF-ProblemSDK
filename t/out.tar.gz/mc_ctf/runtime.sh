#!/bin/bash

./main